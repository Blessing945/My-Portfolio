function toggleMenu(){
    const menu = document.querySelector(".menu-links");
    const icon = document.querySelector(".hamburger-icon");

    menu.classList.toggle("open");
    icon.classList.toggle("open");
}

    function sendWhatsAppMessage() {
      var phoneNumber = "+264813469673"; // Replace with the recipient's phone number
      var message = "Hello, my name is Peneyambeko Hianghumbi. How may I help you? "; // Replace with your desired message
      
      var encodedMessage = encodeURIComponent(message);
      var whatsappURL = "https://wa.me/" + phoneNumber + "?text=" + encodedMessage;
      
      window.open(whatsappURL);
    }